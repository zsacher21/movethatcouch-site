# MOVE THAT COUCH! GitHub Pages homepage export

This folder contains the approved static homepage for `https://movethatcouch.com/`.

## Upload

1. Replace the marketing repository's root `index.html` with this folder's `index.html`.
2. Upload the entire `home-assets/` folder to the repository root.
3. Keep every other existing repository file and folder unchanged, including `CNAME`, `about/`, `contact/`, `marketing/`, `invite/`, `r/`, and any other public routes.
4. Commit to the `main` branch and wait for GitHub Pages to publish.

No existing files need to be removed. Only the root `index.html` is overwritten. The new `home-assets/` folder is additive.

## Production behavior

- Canonical homepage: `https://movethatcouch.com/`
- Homepage brand links: `/`
- About and Contact links: `/about` and `/contact`
- Customer/provider CTAs: `https://app.movethatcouch.com/` with incoming query parameters preserved
- Dynamic reviews: `https://app.movethatcouch.com/api/public/recent-reviews`
- Legal links remain on `https://legal.movethatcouch.com/`

The app's `/` route and `/home-preview` route are intentionally unchanged by this export.